
	function display(value) {
		document.getElementById('dis').value+=value;
	}

	function text() {
			document.getElementById('dis').value=0;
		}

	function sum(){
		operator=('operator');
		if (operator=='+') {
			new=display('')+display('');
			document.getElementById('dis').value=new;
		} else {}
	}

	
	const audio = new Audio();
	audio.src = "HLO.mp3";